package com.example.smart_ahwa_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
