import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'ahwa_logic.dart'; 

void main() {
  final orderRepository = InMemoryOrderRepository();
  final orderManager = OrderManager(orderRepository);
  final salesReporter = SalesReporter(orderRepository);

  orderManager.createOrder(customerName: 'Ahmed', drink: TurkishCoffee(), instructions: 'extra mint, ya rais');
  orderManager.createOrder(customerName: 'Fatima', drink: Shai());

  runApp(MyApp(orderManager: orderManager, salesReporter: salesReporter));
}

class MyApp extends StatelessWidget {
  final OrderManager orderManager;
  final SalesReporter salesReporter;

  const MyApp({required this.orderManager, required this.salesReporter, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF7F2EE),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF6F4E37),
        primary: const Color(0xFF6F4E37),
        secondary: const Color(0xFFE0A96D),
        background: const Color(0xFFF7F2EE),
      ),
      textTheme: GoogleFonts.cairoTextTheme(Theme.of(context).textTheme),
      appBarTheme: AppBarTheme(
        backgroundColor: const Color(0xFF6F4E37),
        foregroundColor: Colors.white,
        elevation: 2,
        titleTextStyle: GoogleFonts.cairo(fontSize: 22, fontWeight: FontWeight.bold),
      ),
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Ahwa Manager',
      theme: theme,
      home: AhwaDashboardScreen(
        orderManager: orderManager,
        salesReporter: salesReporter,
      ),
    );
  }
}

class AhwaDashboardScreen extends StatefulWidget {
  final OrderManager orderManager;
  final SalesReporter salesReporter;

  const AhwaDashboardScreen({required this.orderManager, required this.salesReporter, Key? key}) : super(key: key);

  @override
  _AhwaDashboardScreenState createState() => _AhwaDashboardScreenState();
}

class _AhwaDashboardScreenState extends State<AhwaDashboardScreen> {
  late List<Order> _pendingOrders;

  @override
  void initState() {
    super.initState();
    _refreshOrders();
  }

  void _refreshOrders() {
    setState(() {
      _pendingOrders = widget.orderManager.getPendingOrders();
    });
  }

  void _showDailyReport() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: const Row(children: [Icon(Icons.assessment_outlined), SizedBox(width: 8), Text('Daily Sales Report')]),
        content: Text(widget.salesReporter.generateDailyReport(), style: GoogleFonts.cairo(height: 1.5)),
        actions: [TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close'))],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.coffee_maker_outlined, size: 80, color: Colors.brown.shade300),
          const SizedBox(height: 16),
          Text('No pending orders', style: GoogleFonts.cairo(fontSize: 22, fontWeight: FontWeight.bold)),
          Text('Time to make some coffee!', style: TextStyle(fontSize: 16, color: Colors.grey.shade600)),
        ],
      ),
    );
  }

  Widget _buildOrderCard(Order order) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(child: Text(order.customerName, style: GoogleFonts.cairo(fontSize: 20, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                Text('${order.drink.price.toStringAsFixed(2)} \$', style: GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
              ],
            ),
            const Divider(height: 20),
            Row(children: [Icon(Icons.coffee_outlined, size: 18, color: Colors.brown.shade400), const SizedBox(width: 8), Text(order.drink.name, style: const TextStyle(fontSize: 16, fontStyle: FontStyle.italic))]),
            const SizedBox(height: 8),
            if (order.specialInstructions.toLowerCase() != 'none')
              Row(children: [Icon(Icons.notes_outlined, size: 18, color: Colors.brown.shade400), const SizedBox(width: 8), Expanded(child: Text(order.specialInstructions, style: TextStyle(fontSize: 14, color: Colors.grey.shade700)))]),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                style: IconButton.styleFrom(backgroundColor: Colors.green.shade50, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                icon: const Icon(Icons.check, color: Colors.green),
                onPressed: () {
                  widget.orderManager.markOrderAsCompleted(order);
                  _refreshOrders();
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order for ${order.customerName} completed!'), backgroundColor: Colors.green));
                },
                tooltip: 'Mark as Completed',
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Ahwa Manager'),
        actions: [IconButton(icon: const Icon(Icons.assessment_outlined), onPressed: _showDailyReport, tooltip: 'View Daily Report')],
      ),
      body: _pendingOrders.isEmpty ? _buildEmptyState() : ListView.builder(itemCount: _pendingOrders.length, itemBuilder: (context, index) => _buildOrderCard(_pendingOrders[index])),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (context) => AddOrderScreen(orderManager: widget.orderManager)));
          _refreshOrders();
        },
        tooltip: 'Add New Order',
        child: const Icon(Icons.add),
      ),
    );
  }
}

class AddOrderScreen extends StatefulWidget {
  final OrderManager orderManager;
  const AddOrderScreen({required this.orderManager, super.key});

  @override
  // ignore: library_private_types_in_public_api
  _AddOrderScreenState createState() => _AddOrderScreenState();
}

class _AddOrderScreenState extends State<AddOrderScreen> {
  final _customerNameController = TextEditingController();
  final _instructionsController = TextEditingController();
  Drink? _selectedDrink;
  final List<Drink> _availableDrinks = [Shai(), TurkishCoffee(), HibiscusTea()];

  void _submitOrder() {
    if (_customerNameController.text.trim().isEmpty || _selectedDrink == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill customer name and select a drink.'), backgroundColor: Colors.red));
      return;
    }
    widget.orderManager.createOrder(customerName: _customerNameController.text.trim(), drink: _selectedDrink!, instructions: _instructionsController.text.trim().isNotEmpty ? _instructionsController.text.trim() : 'None');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final inputDecoration = InputDecoration(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade300)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.shade300)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Theme.of(context).colorScheme.primary, width: 2)),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Add New Order')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: _customerNameController, decoration: inputDecoration.copyWith(labelText: 'Customer Name', prefixIcon: const Icon(Icons.person_outline))),
            const SizedBox(height: 16),
            DropdownButtonFormField<Drink>(
              value: _selectedDrink,
              hint: const Text('Select a Drink'),
              decoration: inputDecoration.copyWith(prefixIcon: const Icon(Icons.coffee_outlined)),
              onChanged: (Drink? newValue) { setState(() { _selectedDrink = newValue; }); },
              items: _availableDrinks.map<DropdownMenuItem<Drink>>((Drink drink) => DropdownMenuItem<Drink>(value: drink, child: Text(drink.name))).toList(),
            ),
            const SizedBox(height: 16),
            TextField(controller: _instructionsController, decoration: inputDecoration.copyWith(labelText: 'Special Instructions (Optional)', prefixIcon: const Icon(Icons.notes_outlined))),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _submitOrder,
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), textStyle: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold)),
              child: const Text('Confirm Order'),
            ),
          ],
        ),
      ),
    );
  }
}