abstract class Drink {
  String get name;
  double get price;
}

class Shai implements Drink {
  @override
  String get name => 'Shai';
  @override
  double get price => 5.0;
}

class TurkishCoffee implements Drink {
  @override
  String get name => 'Turkish Coffee';
  @override
  double get price => 10.0;
}

class HibiscusTea implements Drink {
  @override
  String get name => 'Hibiscus Tea';
  @override
  double get price => 7.0;
}

enum OrderStatus { pending, completed }

class Order {
  final String customerName;
  final Drink drink;
  final String specialInstructions;
  OrderStatus status;

  Order({
    required this.customerName,
    required this.drink,
    this.specialInstructions = 'None',
    this.status = OrderStatus.pending,
  });
}


abstract class OrderRepository {
  void addOrder(Order order);
  void completeOrder(Order order);
  List<Order> getPendingOrders();
  List<Order> getAllOrders();
}

class InMemoryOrderRepository implements OrderRepository {
  final List<Order> _orders = [];

  @override
  void addOrder(Order order) {
    _orders.add(order);
  }

  @override
  void completeOrder(Order order) {
    final index = _orders.indexOf(order);
    if (index != -1) {
      _orders[index].status = OrderStatus.completed;
    }
  }

  @override
  List<Order> getPendingOrders() {
    return _orders.where((o) => o.status == OrderStatus.pending).toList();
  }

  @override
  List<Order> getAllOrders() {
    return List.unmodifiable(_orders);
  }
}

class OrderManager {
  final OrderRepository _repository;
  OrderManager(this._repository); 

  void createOrder({
    required String customerName,
    required Drink drink,
    String instructions = 'None',
  }) {
    final newOrder = Order(
        customerName: customerName,
        drink: drink,
        specialInstructions: instructions);
    _repository.addOrder(newOrder);
  }

  void markOrderAsCompleted(Order order) {
    _repository.completeOrder(order);
  }

  List<Order> getPendingOrders() {
    return _repository.getPendingOrders();
  }
}

class SalesReporter {
  final OrderRepository _repository;
  SalesReporter(this._repository);

  String generateDailyReport() {
    final allOrders = _repository.getAllOrders();
    if (allOrders.isEmpty) {
      return 'No orders have been served today.';
    }

    final drinkCounts = <String, int>{};
    for (var order in allOrders) {
      drinkCounts[order.drink.name] = (drinkCounts[order.drink.name] ?? 0) + 1;
    }

    final sortedDrinks = drinkCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    String report = 'Total Orders Served: ${allOrders.length}\n\n';
    report += 'Top-Selling Drinks:\n';
    for (var entry in sortedDrinks) {
      report += '- ${entry.key}: ${entry.value}\n';
    }
    return report;
  }
}